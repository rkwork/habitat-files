# Plan for sample nodejs application
pkg_origin=rkgade
pkg_name=licensemgmt
pkg_version=0.2.0
pkg_maintainer="Raj Kiran Gade <rajkiran.gade@gmail.com>"
pkg_license=('Apache-2.0')
pkg_source='https://github.com/rkgade/licensemgmt/raw/master/licensemgmt-0.2.0.tar.gz'
pkg_shasum=bbdd19c2fe3bc601a4a59f86b8fa4f700f4488e2c0e3438cf7a5c89849359cd3
pkg_filename=${pkg_name}-${pkg_version}.tar.gz
pkg_deps=(core/node chefops/mongodb)
pkg_build_deps=()
pkg_bin_dirs=(bin)
pkg_include_dirs=(include)
pkg_lib_dirs=(lib)
pkg_expose=(9090)


#do_download() {
#  export GIT_SSL_CAINFO="$(pkg_path_for core/cacerts)/ssl/certs/cacert.pem"
#  git clone https://github.com/rkgade/licenseMGMTFinal.git 
#  pushd chef
#  git checkout $pkg_version
#  popd
#  tar -cjvf $HAB_CACHE_SRC_PATH/${pkg_name}-${pkg_version}.tar.bz2 \
#      --transform "s,^\./chef,chef${pkg_version}," ./chef \
#      --exclude chef/.git --exclude chef/spec
#  pkg_shasum=$(trim $(sha256sum $HAB_CACHE_SRC_PATH/${pkg_filename} | cut -d " " -f 1))
#}

do_build() {
  # The mytutorialapp source code is unpacked into a directory,
  # mytutorialapp-0.1.0, at the root of $HAB_CACHE_SRC_PATH. If you were downloading
  # an archive that didn't match your package name and version, you would have to
  # copy the files into $HAB_CACHE_SRC_PATH.

  # This installs both npm as well as the nconf module we listed as a
  # dependency in package.json.
echo "in build"  
}

do_install() {
  # Our source files were copied over to the HAB_CACHE_SRC_PATH in do_build(),
  # so now they need to be copied into the root directory of our package through
  # the pkg_prefix variable. This is so that we have the source files available
  # in the package.
#  cp  * ${pkg_prefix}
echo ${pkg_prefix}
echo "DONE"
find . -maxdepth 1 -type f | xargs cp -t ${pkg_prefix}/
# Copy over the nconf module to the package that we installed in do_build().
  mkdir -p ${pkg_prefix}/node_modules/
  cp -vr node_modules/* ${pkg_prefix}/node_modules/
  mkdir -p ${pkg_prefix}/data/db
}

