# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
RubyRailsSample::Application.config.secret_key_base = '75b0702803acc74b3fa924d4f31448cdbf763c2f867fe780bc9ac52e4b5c56861685f2bf6c5ae5e97045e09a627aabed18b140b473c087195dec705a23eee0ac'
